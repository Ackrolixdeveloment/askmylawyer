module.exports = [
"[project]/.next-internal/server/app/lawyers/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_lawyers_page_actions_1ypmgf5.js.map