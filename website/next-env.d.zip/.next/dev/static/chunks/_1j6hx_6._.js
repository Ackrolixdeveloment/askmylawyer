(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__146d930._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/node_modules_0hur0o5._.js","static/chunks/src_0li26am._.js"],
    source: "entry"
});
