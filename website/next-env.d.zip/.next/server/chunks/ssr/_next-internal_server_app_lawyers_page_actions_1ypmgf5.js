module.exports=[84840,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_lawyers_page_actions_1ypmgf5.js.map